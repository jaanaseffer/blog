<script>
    // Error translations
    SERVER_ERROR_UNKNOWN_FORMAT = '<?=__('Server returned response in an unexpected format')?>';
    SERVER_ERROR_FORBIDDEN = '<?=__('Forbidden')?>';
    SERVER_ERROR_OTHER = '<?=__('Server returned an error. Please try again later ')?>';
</script>